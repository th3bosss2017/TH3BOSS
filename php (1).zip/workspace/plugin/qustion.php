<?php
if($text == 'ابدا'){
bot('sendChatAction', [
'chat_id'=>$chat_id,
'action'=>'typing'
]);
sleep(2);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'حسنا عزيزي',
]);  
sleep(2);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"انا اضن انك ليس مستعد لبدا الاختبار\nاذا كنت مستعد ارسل انا مستعد \n ان لم تكن مستعد ارسل غير مستعد",
]);
}
if($text == 'انا مستعد'){
bot('sendChatAction', [
'chat_id'=>$chat_id,
'action'=>'typing'
]);
sleep(1);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"هذا رائع فلنبدا",
]);
bot('sendChatAction', [
'chat_id'=>$chat_id,
'action'=>'typing'
]);
sleep(3);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"السؤال الاول \nرقم اذا ضرب في الرقم الذي يليه كان حاصل الضرب يساوي ناتج الجمع +11 فما هما؟ \n4,5\n6,4\n5,2",
]); 
}
if(stristr($text,'4,5')){
bot('sendChatAction', [
'chat_id'=>$chat_id,
'action'=>'typing'
]);
sleep(2);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"الاجابه صحيحه عزيزي",
]); 
}

if($text == 'غير مستعد'){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"ننتضرك في المره المقبله",
]); 
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"الى القاء",
]); 
}

?>