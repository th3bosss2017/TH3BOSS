<?php
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$text = $message->text;
$chat_id = $message->chat->id;
$message_id = $message->message_id;
$msg_type = $message->chat->type; //رسائل خاص او مجموعه
$id_me = $message->from->id;

$chatid = $update->callback_query->message->chat->id;
$data = $update->callback_query->data;
$query=$update->callback_query;
$inline=$update->inline_query;
$channel_forward = $update->channel_post->forward_from;
$channel_text = $update->channel_post->text;
$messageid = $update->callback_query->message->message_id;

$proadmin = file_get_contents("https://api.telegram.org/bot".API_KEY."/getChatMember?chat_id=$chat_id&user_id=".$id_me);


$sudo_id = 60809019;
if($text == '/start' and $msg_type == 'supergroup'){
  bot('sendMessage', [
  'chat_id'=>$chat_id,
  'text'=>'welcome command group',
  'reply_to_message_id'=>$message_id
  ]);
  }
/////////////////////command lock sticker \\\\\\\\\\\\\\\\\\\\\
$sticker = $message->sticker;
$sticker_get = file_get_contents('tg/sticker.txt');
$sticker_ex = explode("\n", $sticker_get);
if($text == 'قفل الملصقات' and strpos($proadmin , '"status":"member"') == false and !in_array($chat_id, $sticker_ex)){
file_put_contents('tg/sticker.txt',$chat_id."\n" ,FILE_APPEND);
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟|   تم قفل الملصقات ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($text == 'قفل الملصقات' and strpos($proadmin , '"status":"member"') == false and in_array($chat_id, $sticker_ex)){
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟| الملصقات بالتأكيد تم قفلها ☑️",
'reply_to_message_id'=>$message_id
]);
}
//  & #  الزعيم مجمد هشام &  ضرغام احمد
if($text == 'فتح الملصقات' and strpos($proadmin , '"status":"member"') == false and in_array($chat_id , $sticker_ex)){
$send = file_get_contents("tg/sticker.txt");
$send = str_replace($chat_id, " ", $send);
$send = preg_replace("/(^[\r\n]*|[\r\n]+)[\s\t]*[\r\n]+/", "\n", $send);
file_put_contents('tg/sticker.txt', $send);
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟|   تم فتح الملصقات ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($text == 'فتح الملصقات'and strpos($proadmin , '"status":"member"') == false and !in_array($chat_id , $sticker_ex)){
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟| الملصقات بالتأكيد تم فتحها ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($sticker and strpos($proadmin , '"status":"member"') !== false and in_array($chat_id , $sticker_ex)){
bot('deleteMessage',[
'chat_id'=>$chat_id,
'message_id'=>$message_id
]);
}
/////////////////////command end lock sticker \\\\\\\\\\\\\\\\\\\\\

/////////////////////command lock photo \\\\\\\\\\\\\\\\\\\\\
$photo = $message->photo;
$photo_get = file_get_contents('tg/photo.txt');
$photo_ex = explode("\n", $photo_get);
if($text == 'قفل الصور' and strpos($proadmin , '"status":"member"') == false and !in_array($chat_id, $photo_ex)){
file_put_contents('tg/photo.txt',$chat_id."\n" ,FILE_APPEND);
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟| تم قفل الصور ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($text == 'قفل الصور' and strpos($proadmin , '"status":"member"') == false and in_array($chat_id, $photo_ex)){
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟| الصور بالتأكيد تم قفلها ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($text == 'فتح الصور' and strpos($proadmin , '"status":"member"') == false and in_array($chat_id , $photo_ex)){
$send = file_get_contents("tg/photo.txt");
$send = str_replace($chat_id, " ", $send);
$send = preg_replace("/(^[\r\n]*|[\r\n]+)[\s\t]*[\r\n]+/", "\n", $send);
file_put_contents('tg/photo.txt', $send);
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟| تم فتح الصور ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($text == 'فتح الصور' and strpos($proadmin , '"status":"member"') == false and !in_array($chat_id , $photo_ex)){
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟| الصور بالتأكيد تم فتحها ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($photo and strpos($proadmin , '"status":"member"') !== false and in_array($chat_id , $photo_ex)){
bot('deleteMessage',[
'chat_id'=>$chat_id,
'message_id'=>$message_id
]);
}
/////////////////////command end lock photo \\\\\\\\\\\\\\\\\\\\\

/////////////////////command lock voice \\\\\\\\\\\\\\\\\\\\\
$voice = $message->voice;
$voice_get = file_get_contents('tg/voice.txt');
$voice_ex = explode("\n", $voice_get);
if($text == 'قفل الصوت' and strpos($proadmin , '"status":"member"') == false and !in_array($chat_id, $voice_ex)){
file_put_contents('tg/voice.txt',$chat_id."\n" ,FILE_APPEND);
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟|   تم قفل الصوت ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($text == 'قفل الصوت' and strpos($proadmin , '"status":"member"') == false and in_array($chat_id, $voice_ex)){
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟| الصوت بالتأكيد تم قفله ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($text == 'فتح الصوت' and strpos($proadmin , '"status":"member"') == false and in_array($chat_id , $voice_ex)){
$send = file_get_contents("tg/voice.txt");
$send = str_replace($chat_id, " ", $send);
$send = preg_replace("/(^[\r\n]*|[\r\n]+)[\s\t]*[\r\n]+/", "\n", $send);
file_put_contents('tg/voice.txt', $send);
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟|   تم فتح الصوت ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($text == 'قتح الصوت' and strpos($proadmin , '"status":"member"') == false and !in_array($chat_id , $voice_ex)){
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟| الصوت بالتأكيد تم فتحه ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($voice and strpos($proadmin , '"status":"member"') !== false and in_array($chat_id , $voice_ex)){
bot('deleteMessage',[
'chat_id'=>$chat_id,
'message_id'=>$message_id
]);
}
/////////////////////command end lock voice \\\\\\\\\\\\\\\\\\\\\

/////////////////////command lock video \\\\\\\\\\\\\\\\\\\\\
$video = $message->video;
$video_get = file_get_contents('tg/video.txt');
$video_ex = explode("\n", $video_get);
if($text == 'قفل الفيديو' and strpos($proadmin , '"status":"member"') == false and !in_array($chat_id, $video_ex)){
file_put_contents('tg/video.txt',$chat_id."\n" ,FILE_APPEND);
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟|   تم قفل الفيديو ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($text == 'قفل الفيديو' and strpos($proadmin , '"status":"member"') == false and in_array($chat_id, $video_ex)){
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟| الفيديو بالتأكيد تم قفله ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($text == 'فتح الفيديو' and strpos($proadmin , '"status":"member"') == false and in_array($chat_id , $video_ex)){
$send = file_get_contents("tg/video.txt");
$send = str_replace($chat_id, " ", $send);
$send = preg_replace("/(^[\r\n]*|[\r\n]+)[\s\t]*[\r\n]+/", "\n", $send);
file_put_contents('tg/video.txt', $send);
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟|   تم فتح الفيديو ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($text == 'فتح الفيديو' and strpos($proadmin , '"status":"member"') == false and !in_array($chat_id , $video_ex)){
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟| الفيديو بالتأكيد تم فتحه ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($video and strpos($proadmin , '"status":"member"') !== false and in_array($chat_id , $video_ex)){
bot('deleteMessage',[
'chat_id'=>$chat_id,
'message_id'=>$message_id
]);
}
/////////////////////command end lock video \\\\\\\\\\\\\\\\\\\\\

/////////////////////command lock audio \\\\\\\\\\\\\\\\\\\\\
$audio = $message->audio;
$audio_get = file_get_contents('tg/audio.txt');
$audio_ex = explode("\n", $audio_get);
if($text == 'قفل البصمات' and strpos($proadmin , '"status":"member"') == false and !in_array($chat_id, $audio_ex)){
file_put_contents('tg/audio.txt',$chat_id."\n" ,FILE_APPEND);
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟|   تم قفل البصمات ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($text == 'قفل البصمات' and strpos($proadmin , '"status":"member"') == false and in_array($chat_id, $audio_ex)){
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟| البصمات بالتأكيد تم قفلها ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($text == 'فتح البصمات' and strpos($proadmin , '"status":"member"') == false and in_array($chat_id , $audio_ex)){
$send = file_get_contents("tg/audio.txt");
$send = str_replace($chat_id, " ", $send);
$send = preg_replace("/(^[\r\n]*|[\r\n]+)[\s\t]*[\r\n]+/", "\n", $send);
file_put_contents('tg/audio.txt', $send);
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟|   تم فتح البصمات ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($text == 'فتح البصمات' and strpos($proadmin , '"status":"member"') == false and !in_array($chat_id , $audio_ex)){
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟| البصمات بالتأكيد تم فتحها ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($audio and strpos($proadmin , '"status":"member"') !== false and in_array($chat_id , $audio_ex)){
bot('deleteMessage',[
'chat_id'=>$chat_id,
'message_id'=>$message_id
]);
}
/////////////////////command end lock audio \\\\\\\\\\\\\\\\\\\\\

/////////////////////command lock document \\\\\\\\\\\\\\\\\\\\\
$document = $message->document;
$document_get = file_get_contents('tg/document.txt');
$document_ex = explode("\n", $document_get);
if($text == 'قفل الملفات' and strpos($proadmin , '"status":"member"') == false and !in_array($chat_id, $document_ex)){
file_put_contents('tg/document.txt',$chat_id."\n" ,FILE_APPEND);
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟|   تم قفل الملفات ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($text == 'قفل الملفات' and strpos($proadmin , '"status":"member"') == false and in_array($chat_id, $document_ex)){
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟| الملفات بالتأكيد تم قفلها ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($text == 'فتح الملفات' and strpos($proadmin , '"status":"member"') == false and in_array($chat_id , $document_ex)){
$send = file_get_contents("tg/document.txt");
$send = str_replace($chat_id, " ", $send);
$send = preg_replace("/(^[\r\n]*|[\r\n]+)[\s\t]*[\r\n]+/", "\n", $send);
file_put_contents('tg/document.txt', $send);
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟|   تم فتح الملفات ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($text == 'فتح الملفات' and strpos($proadmin , '"status":"member"') == false and !in_array($chat_id , $document_ex)){
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟| الملفات بالتأكيد تم فتحها ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($document and strpos($proadmin , '"status":"member"') !== false and in_array($chat_id , $document_ex)){
bot('deleteMessage',[
'chat_id'=>$chat_id,
'message_id'=>$message_id
]);
}
/////////////////////command end lock document \\\\\\\\\\\\\\\\\\\\\

/////////////////////command lock text \\\\\\\\\\\\\\\\\\\\\
$text = $message->text;
$text_get = file_get_contents('tg/text.txt');
$text_ex = explode("\n", $text_get);
if($text == 'قفل الدردشه' and strpos($proadmin , '"status":"member"') == false and !in_array($chat_id, $text_ex)){
file_put_contents('tg/text.txt',$chat_id."\n" ,FILE_APPEND);
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟|   تم قفل الدردشه ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($text == 'قفل الدردشه' and strpos($proadmin , '"status":"member"') == false and in_array($chat_id, $text_ex)){
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟| الدردشه بالتأكيد تم قفلها ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($text == 'فتح الدردشه' and strpos($proadmin , '"status":"member"') == false and in_array($chat_id , $text_ex)){
$send = file_get_contents("tg/text.txt");
$send = str_replace($chat_id, " ", $send);
$send = preg_replace("/(^[\r\n]*|[\r\n]+)[\s\t]*[\r\n]+/", "\n", $send);
file_put_contents('tg/text.txt', $send);
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟|   تم فتح الدردشه ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($text == 'فتح الدردشه' and strpos($proadmin , '"status":"member"') == false and !in_array($chat_id , $text_ex)){
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟| الدردشه بالتأكيد تم فتحها ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($text and strpos($proadmin , '"status":"member"') !== false and in_array($chat_id , $text_ex)){
bot('deleteMessage',[
'chat_id'=>$chat_id,
'message_id'=>$message_id
]);
}
/////////////////////command end  lock text \\\\\\\\\\\\\\\\\\\\\

/////////////////////command lock forward \\\\\\\\\\\\\\\\\\\\\
$forward = $message->forward_from->id;
$forward_get = file_get_contents('tg/forward.txt');
$forward_ex = explode("\n", $forward_get);
if($text == 'قفل التوجيه' and strpos($proadmin , '"status":"member"') == false and !in_array($chat_id, $forward_ex)){
file_put_contents('tg/forward.txt',$chat_id."\n" ,FILE_APPEND);
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟|   تم قفل التوجيه ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($text == 'قفل التوجيه' and strpos($proadmin , '"status":"member"') == false and in_array($chat_id, $forward_ex)){
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟| التوجيه بالتأكيد تم قفلها ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($text == 'فتح التوجيه' and strpos($proadmin , '"status":"member"') == false and in_array($chat_id , $forward_ex)){
$send = file_get_contents("tg/forward.txt");
$send = str_replace($chat_id, " ", $send);
$send = preg_replace("/(^[\r\n]*|[\r\n]+)[\s\t]*[\r\n]+/", "\n", $send);
file_put_contents('tg/forward.txt', $send);
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟|   تم فتح التوجيه ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($text == 'فتح التوجيه' and strpos($proadmin , '"status":"member"') == false and !in_array($chat_id , $forward_ex)){
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟| التوجيه بالتأكيد تم فتحها ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($forward and strpos($proadmin , '"status":"member"') !== false and in_array($chat_id , $forward_ex)){
bot('deleteMessage',[
'chat_id'=>$chat_id,
'message_id'=>$message_id
]);
}
/////////////////////command end lock forward \\\\\\\\\\\\\\\\\\\\\

/////////////////////command lock link \\\\\\\\\\\\\\\\\\\\\
$link_get = file_get_contents('tg/link.txt');
$link_ex = explode("\n", $link_get);
if($text == 'قفل الروابط' and strpos($proadmin , '"status":"member"') == false and !in_array($chat_id, $link_ex)){
file_put_contents('tg/link.txt',$chat_id."\n" ,FILE_APPEND);
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟|   تم قفل الروابط  ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($text == 'قفل الروابط' and strpos($proadmin , '"status":"member"') == false and in_array($chat_id, $link_ex)){
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟| الروابط بالتأكيد تم قفلها ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($text == 'فتح الروابط' and strpos($proadmin , '"status":"member"') == false  and in_array($chat_id , $link_ex)){
$send = file_get_contents("tg/link.txt");
$send = str_replace($chat_id, " ", $send);
$send = preg_replace("/(^[\r\n]*|[\r\n]+)[\s\t]*[\r\n]+/", "\n", $send);
file_put_contents('tg/link.txt', $send);
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟|   تم فتح الروابط  ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($text == 'فتح الروابط' and strpos($proadmin , '"status":"member"') == false and !in_array($chat_id , $link_ex)){
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟| الروابط بالتأكيد تم فتحها ☑️",
'reply_to_message_id'=>$message_id
]);
}
 if(preg_match('/^(.*)([Hh]ttp|[Hh]ttps|t.me)(.*)|([Hh]ttp|[Hh]ttps|t.me)(.*)|(.*)([Hh]ttp|[Hh]ttps|t.me)|(.*)[Tt]elegram.me(.*)|[Tt]elegram.me(.*)|(.*)[Tt]elegram.me|(.*)[Tt].me(.*)|[Tt].me(.*)|(.*)[Tt].me/',$text) ){
  bot('deleteMessage',[
  'chat_id'=>$chat_id,
  'message_id'=>$message_id
  ]);
}
/////////////////////command end lock link \\\\\\\\\\\\\\\\\\\\\

/////////////////////command lock tag \\\\\\\\\\\\\\\\\\\\\
$tag_get = file_get_contents('tg/tag.txt');
$tag_ex = explode("\n", $tag_get);
if($text == 'قفل التاك' and strpos($proadmin , '"status":"member"') == false and !in_array($chat_id, $tag_ex)){
file_put_contents('tg/tag.txt',"\n". $chat_id ,FILE_APPEND);
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟|   تم قفل التاك ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($text == 'قفل التاك' and strpos($proadmin , '"status":"member"') == false and in_array($chat_id, $tag_ex)){
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟| التاك بالتأكيد تم قفله ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($text == 'فتح التاك' and strpos($proadmin , '"status":"member"') == false and in_array($chat_id , $tag_ex)){
$send = file_get_contents("tg/tag.txt");
$send = str_replace($chat_id, " ", $send);
$send = preg_replace("/(^[\r\n]*|[\r\n]+)[\s\t]*[\r\n]+/", "\n", $send);
file_put_contents('tg/tag.txt', $send);
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟|   تم فتح التاك ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($text == 'فتح التاك' and strpos($proadmin , '"status":"member"') == false and !in_array($chat_id , $tag_ex)){
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟| التاك بالتأكيد تم فتحه ☑️",
'reply_to_message_id'=>$message_id
]);
}
if(preg_match('/#/',$text)and strpos($proadmin , '"status":"member"') !== false and in_array($chat_id , $tag_ex)){
  bot('deleteMessage',[
  'chat_id'=>$chat_id,
  'message_id'=>$message_id
  ]);
}
/////////////////////command end lock tag \\\\\\\\\\\\\\\\\\\\\

/////////////////////command lock user \\\\\\\\\\\\\\\\\\\\\
$user_get = file_get_contents('tg/user.txt');
$user_ex = explode("\n", $user_get);
if($text ==  'قفل المعرفات' and strpos($proadmin , '"status":"member"') == false and !in_array($chat_id, $user_ex)){
file_put_contents('tg/user.txt',"\n". $chat_id ,FILE_APPEND);
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟|   تم قفل المعرفات ☑️",

'reply_to_message_id'=>$message_id
]);
}
if($text == 'قفل المعرفات' and strpos($proadmin , '"status":"member"') == false and in_array($chat_id, $user_ex)){
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟| المعرفات بالتأكيد تم قفلها ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($text == 'فتح المعرفات' and strpos($proadmin , '"status":"member"') == false and in_array($chat_id , $user_ex)){
$send = file_get_contents("tg/user.txt");
$send = str_replace($chat_id, " ", $send);
$send = preg_replace("/(^[\r\n]*|[\r\n]+)[\s\t]*[\r\n]+/", "\n", $send);
file_put_contents('tg/user.txt', $send);
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟|   تم فتح المعرفات ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($text == 'فتح المعرفات' and strpos($proadmin , '"status":"member"') == false and !in_array($chat_id , $user_ex)){
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟| المعرفات بالتأكيد تم فتحها ☑️",
'reply_to_message_id'=>$message_id
]);
}
if(preg_match('/@/',$text)and strpos($proadmin , '"status":"member"') !== false and in_array($chat_id , $user_ex)){
bot('deleteMessage',[
'chat_id'=>$chat_id,
'message_id'=>$message_id
]);
}
/////////////////////command end lock user \\\\\\\\\\\\\\\\\\\\\

/////////////////////command lock reply \\\\\\\\\\\\\\\\\\\\\
$replyy = $message->forward_from->id;
$replyy_get = file_get_contents('tg/replyy.txt');
$replyy_ex = explode("\n", $replyy_get);
if($text == 'قفل الردود' and strpos($proadmin , '"status":"member"') == false and !in_array($chat_id, $replyy_ex)){
file_put_contents('tg/replyy.txt',$chat_id."\n" ,FILE_APPEND);
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟|   تم قفل الردود ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($text == 'قفل الردود' and strpos($proadmin , '"status":"member"') == false and in_array($chat_id, $replyy_ex)){
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟| الردود بالتأكيد تم قفلها ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($text == 'فتح الردود' and strpos($proadmin , '"status":"member"') == false and in_array($chat_id , $replyy_ex)){
$send = file_get_contents("tg/replyy.txt");
$send = str_replace($chat_id, " ", $send);
$send = preg_replace("/(^[\r\n]*|[\r\n]+)[\s\t]*[\r\n]+/", "\n", $send);
file_put_contents('tg/replyy.txt', $send);
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟|   تم فتح الردود ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($text == 'فتح الردود' and strpos($proadmin , '"status":"member"') == false and !in_array($chat_id , $replyy_ex)){
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟| الردود بالتأكيد تم فتحها ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($forward and strpos($proadmin , '"status":"member"') !== false and in_array($chat_id , $replyy_ex)){
bot('deleteMessage',[
'chat_id'=>$chat_id,
'message_id'=>$message_id
]);
}
/////////////////////command end lock reply \\\\\\\\\\\\\\\\\\\\\

/////////////////////command lock english \\\\\\\\\\\\\\\\\\\\\
$english_get = file_get_contents('tg/english.txt');
$english_ex = explode("\n", $english_get);
if($text == 'قفل الانكلش' and strpos($proadmin , '"status":"member"') == false and !in_array($chat_id, $english_ex)){
file_put_contents('tg/english.txt',$chat_id."\n" ,FILE_APPEND);
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟|   تم قفل الانكلش ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($text == 'قفل الانكلش' and strpos($proadmin , '"status":"member"') == false and in_array($chat_id, $english_ex)){
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟| الانكلش بالتأكيد تم قفلها ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($text == 'فتح الانكلس' and strpos($proadmin , '"status":"member"') == false and in_array($chat_id , $english_ex)){
$send = file_get_contents("tg/english.txt");
$send = str_replace($chat_id, " ", $send);
$send = preg_replace("/(^[\r\n]*|[\r\n]+)[\s\t]*[\r\n]+/", "\n", $send);
file_put_contents('tg/english.txt', $send);
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟|   تم فتح الانكلش ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($text == 'فتح الانكلش' and strpos($proadmin , '"status":"member"') == false and !in_array($chat_id , $english_ex)){
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟| الانكلش بالتأكيد تم فتحها ☑️",
'reply_to_message_id'=>$message_id
]);
}
function writeMessage($text) {
if(stristr($text,"a" ) or stristr($text, 'b') or stristr($text, 'c') or stristr($text, 'd') or stristr($text, 'e') or stristr($text, 'f') or stristr($text, 'g') or stristr($text, 'h') or stristr($text, 'i') or stristr($text, 'j') or stristr($text, 'k') or stristr($text, 'l') or stristr($text, 'm') or stristr($text, 'n') or stristr($text, 'o') or stristr($text, 'p') or stristr($text, 'q') or stristr($text, 'r') or stristr($text, 's') or stristr($text, 't') or stristr($text, 'u') or stristr($text, 'v') or stristr($text, 'w') or stristr($text, 'x') or stristr($text, 'y') or stristr($text, 'z')) {
return true;
}
else
{
return false;
}
}
$eng = writeMessage($text);
if($eng and strpos($proadmin , '"status":"member"') !== false and in_array($chat_id , $english_ex)){
 bot('deleteMessage',[
'chat_id'=>$chat_id,
  'message_id'=>$message_id
  ]);
}
/////////////////////command end lock english \\\\\\\\\\\\\\\\\\\\\

/////////////////////command lock badword \\\\\\\\\\\\\\\\\\\\\
$badword_get = file_get_contents('tg/badword.txt');
$badword_ex = explode("\n", $badword_get);
if($text == 'قفل المنع' and strpos($proadmin , '"status":"member"') == false and !in_array($chat_id, $badword_ex)){
file_put_contents('tg/badword.txt',$chat_id."\n" ,FILE_APPEND);
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟|   تم قفل المنع ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($text == 'قفل المنع' and strpos($proadmin , '"status":"member"') == false and in_array($chat_id, $badword_ex)){
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟| المنع بالتأكيد تم قفلها ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($text == 'فتح المنع' and strpos($proadmin , '"status":"member"') == false and in_array($chat_id , $badword_ex)){
$send = file_get_contents("tg/badword.txt");
$send = str_replace($chat_id, " ", $send);
$send = preg_replace("/(^[\r\n]*|[\r\n]+)[\s\t]*[\r\n]+/", "\n", $send);
file_put_contents('tg/badword.txt', $send);
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟|   تم فتح المنع ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($text == 'فتح المنع' and strpos($proadmin , '"status":"member"') == false and !in_array($chat_id , $badword_ex)){
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟| المنع بالتأكيد تم فتحها ☑️",
'reply_to_message_id'=>$message_id
]);
}
function secWyp($text) {
if(stristr($text,"ابن الكحبه" ) or stristr($text, 'كحبه') or stristr($text, 'عير') or stristr($text, 'كس') or stristr($text, 'زب') or stristr($text, 'كحبة') or stristr($text, 'عيوره') or stristr($text, 'كسي') or stristr($text, 'ابن العير') or stristr($text, 'عير بيكم') or stristr($text, 'ابعصكم') or stristr($text, 'انيجك') or stristr($text, 'زبي بيكم') or stristr($text, 'خوات الكحبه') or stristr($text, 'انيجكم') or stristr($text, 'انيج امك') or stristr($text, 'انيجك') or stristr($text, 'كس اختك') or stristr($text, 'عير بمك') or stristr($text, 'كس امك') or stristr($text, 'ابن الكس') or stristr($text, 'كسمك')) {
return true;
}
else
{
return false;
}
  
}
$badowrd = secWyp($text);
if($badowrd and strpos($proadmin , '"status":"member"') !== false and in_array($chat_id , $badword_ex)){
 bot('deleteMessage',[
'chat_id'=>$chat_id,
  'message_id'=>$message_id
  ]);

}
/////////////////////command end lock badword \\\\\\\\\\\\\\\\\\\\\

/////////////////////command lock emoji \\\\\\\\\\\\\\\\\\\\\

$emoji_get = file_get_contents('tg/emoji.txt');
$emoji_ex = explode("\n", $emoji_get);
if($text == 'قفل الاسمايلات' and strpos($proadmin , '"status":"member"') == false and !in_array($chat_id, $emoji_ex)){
file_put_contents('tg/emoji.txt',$chat_id."\n" ,FILE_APPEND);
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟|   تم قفل الاسمايلات ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($text == 'قفل الاسمايلات' and strpos($proadmin , '"status":"member"') == false and in_array($chat_id, $emoji_ex)){
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟| الاسمايلات بالتأكيد تم قفلها ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($text == 'فتح الاسمايلات' and strpos($proadmin , '"status":"member"') == false and in_array($chat_id , $emoji_ex)){
$send = file_get_contents("tg/emoji.txt");
$send = str_replace($chat_id, " ", $send);
$send = preg_replace("/(^[\r\n]*|[\r\n]+)[\s\t]*[\r\n]+/", "\n", $send);
file_put_contents('tg/emoji.txt', $send);
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟|   تم فتح الاسمايلات ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($text == 'فتح الاسمايلات' and strpos($proadmin , '"status":"member"') == false and !in_array($chat_id , $emoji_ex)){
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟| الاسمايلات بالتأكيد تم فتحها ☑️",
'reply_to_message_id'=>$message_id
]);
}
function faron($text) {
if(stristr($text,"😂" ) or stristr($text, '❤️') or stristr($text, '🙊') or stristr($text,'😁') or stristr($text, '🐸') or stristr($text, '💋') or stristr($text, '👍🏻') or stristr($text, '😕') or stristr($text, '😐') or stristr($text, '😄') or stristr($text, '😔') or stristr($text, '👍') or stristr($text, '😢') or stristr($text, '😃') or stristr($text, '😍') or stristr($text, '😘') or stristr($text, '😞') or stristr($text, '😌') or stristr($text, '😅') or stristr($text, '🙈') or stristr($text, '😜') or stristr($text, '😋') or stristr($text, '😚') or stristr($text, '☺️')or stristr($text, '😊')or stristr($text, '😆')or stristr($text, '😒')or stristr($text, '😭')or stristr($text, '😱')or stristr($text, '😝')or stristr($text, '😎')or stristr($text, '😀')or stristr($text, '😳')or stristr($text, '😉')or stristr($text, '👌🏻')or stristr($text, '😀')or stristr($text, '😏')or stristr($text, '😶')or stristr($text, '😻')or stristr($text, '😹')or stristr($text, '😪')or stristr($text, '😴')or stristr($text, '🤔')or stristr($text, '😬')or stristr($text, '🤥')or stristr($text, '🤔')or stristr($text, '😥')or stristr($text, '🤐')or stristr($text, '😓')or stristr($text, '🤤')or stristr($text, '🙊')or stristr($text, '😢')or stristr($text, '🐯')or stristr($text, '🐱')or stristr($text, '🙉')or stristr($text, '🐵')or stristr($text, '🙈')or stristr($text, '🐊')or stristr($text, '🌝')or stristr($text, '🐸')or stristr($text, '🐉')or stristr($text, '🌚')or stristr($text, '🌞')or stristr($text, '😷')or stristr($text, '🤧')or stristr($text, '🤢')or stristr($text, '🤐')or stristr($text, '😯')or stristr($text, '😑')or stristr($text, '😤')or stristr($text, '😲')or stristr($text, '😖')or stristr($text, '😩')or stristr($text, '😵')or stristr($text, '😦')or stristr($text, '😡')){
return true;
}
else
{
return false;
}
  
}
$emoji = faron($text);
if($emoji and strpos($proadmin , '"status":"member"') !== false and in_array($chat_id , $emoji_ex)){
 bot('deleteMessage',[
'chat_id'=>$chat_id,
  'message_id'=>$message_id
  ]);

}
///////////////// command end  lock emoji \\\\\\\\\\\\\\\\\\

///////////////// command   lock arabic \\\\\\\\\\\\\\\\\\
$arabic_get = file_get_contents('tg/arabic.txt');
$arabic_ex = explode("\n", $arabic_get);
if($text == 'قفل العربيه' and strpos($proadmin , '"status":"member"') == false and !in_array($chat_id, $arabic_ex)){
file_put_contents('tg/arabic.txt',$chat_id."\n" ,FILE_APPEND);
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟|   تم قفل العربيه ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($text == 'قفل العربيه' and strpos($proadmin , '"status":"member"') == false and in_array($chat_id, $arabic_ex)){
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟| العربيه بالتأكيد تم قفلها ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($text == 'فتح العربيه' and strpos($proadmin , '"status":"member"') == false and in_array($chat_id , $arabic_ex)){
$send = file_get_contents("tg/arabic.txt");
$send = str_replace($chat_id, " ", $send);
$send = preg_replace("/(^[\r\n]*|[\r\n]+)[\s\t]*[\r\n]+/", "\n", $send);
file_put_contents('tg/arabic.txt', $send);
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟|   تم فتح العربيه ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($text == 'فتح العربيه' and strpos($proadmin , '"status":"member"') == false and !in_array($chat_id , $arabic_ex)){
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟| العربيه بالتأكيد تم فتحها ☑️",
'reply_to_message_id'=>$message_id
]);
}
function arabic($text) {
if(stristr($text,"ض" )or stristr($text, 'ش')or stristr($text, 'ئ')or stristr($text, 'ص')or stristr($text, 'س')or stristr($text, 'ء')or stristr($text, 'ث')or stristr($text, 'ي')or stristr($text, 'ؤ')or stristr($text, 'ق')or stristr($text, 'ب')or stristr($text, 'ر')or stristr($text, 'ف')or stristr($text, 'ل')or stristr($text, 'لا')or stristr($text, 'غ')or stristr($text, 'ا')or stristr($text, 'ى')or stristr($text, 'ع')or stristr($text, 'ت')or stristr($text, 'ة')or stristr($text, 'ه')or stristr($text, 'ن')or stristr($text, 'ن')or stristr($text, 'و')or stristr($text, 'خ')or stristr($text, 'ك')or stristr($text, 'ز')or stristr($text, 'ح')or stristr($text, 'ظ')or stristr($text, 'ط')or stristr($text, 'ذ')or stristr($text, 'د')or stristr($text, 'ج')){
return true;
}
else
{
return false;
}
  
}
$arabic = arabic($text);
if($arabic and strpos($proadmin , '"status":"member"') !== false and in_array($chat_id , $arabic_ex)){
 bot('deleteMessage',[
'chat_id'=>$chat_id,
  'message_id'=>$message_id
  ]);

}
////command en lock arabic\\\\\\\\\\\\\\\\\
$movements_get = file_get_contents('tg/movements.txt');
$movements_ex = explode("\n", $movements_get);
if($text == 'قفل الاشارات' and strpos($proadmin , '"status":"member"') == false and !in_array($chat_id, $movements_ex)){
file_put_contents('tg/movements.txt',$chat_id."\n" ,FILE_APPEND);
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟|   تم قفل الاشارات ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($text == 'قفل الاشارات' and strpos($proadmin , '"status":"member"') == false and in_array($chat_id, $movements_ex)){
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟| الاشارات بالتأكيد تم قفلها ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($text == 'فتح الاشارات' and strpos($proadmin , '"status":"member"') == false and in_array($chat_id , $movements_ex)){
$send = file_get_contents("tg/movements.txt");
$send = str_replace($chat_id, " ", $send);
$send = preg_replace("/(^[\r\n]*|[\r\n]+)[\s\t]*[\r\n]+/", "\n", $send);
file_put_contents('tg/movements.txt', $send);
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟|   تم فتح الاشارات ☑️",
'reply_to_message_id'=>$message_id
]);
}
if($text == 'فتح الاشارات' and strpos($proadmin , '"status":"member"') == false and !in_array($chat_id , $movements_ex)){
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"🌟| مرحبا عزيزي\n🌟| الاشارات بالتأكيد تم فتحها ☑️",
'reply_to_message_id'=>$message_id
]);
}
function movements($text) {
if(stristr($text,"!" )or stristr($text, '@')or stristr($text, '#')or stristr($text, '$')or stristr($text, '%')or stristr($text, '^')or stristr($text, '&')or stristr($text, '*')or stristr($text, '(')or stristr($text, ')')or stristr($text, '_')or stristr($text, '-')or stristr($text, '=')or stristr($text, '+')or stristr($text, '}')or stristr($text, '{')or stristr($text, '/')or stristr($text, '|')or stristr($text, '?')or stristr($text, '؟')or stristr($text, '?')or stristr($text, ',')or stristr($text, '.')or stristr($text, ';')){
return true;
}
else
{
return false;
}
  
}
$movements = movements($text);
if($movements and strpos($proadmin , '"status":"member"') !== false and in_array($chat_id , $movements_ex)){
 bot('deleteMessage',[
'chat_id'=>$chat_id,
  'message_id'=>$message_id
  ]);

}