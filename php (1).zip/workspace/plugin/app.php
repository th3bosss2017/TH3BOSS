<?php
  if(preg_match('/^\/(app) (.*)/s',$text)){
    preg_match('/^\/(app) (.*)/s',$text,$match);
    $rs = 'https://play.google.com/store/search?q='.urlencode($match[2]);
    $rs1 = 'http://www.mobogenie.com/search.html?q='.urlencode($match[2]);
    $rs2 = 'http://www.mobomarket.net/search?keyword='.urlencode($match[2]);
    $rs3 = "http://www.apkmirror.com/?s=".urlencode($match[2])."&post_type=app_release&searchtype=apk";
    $rs4 = 'http://www.appsodo.com/search_'.urlencode($match[2])."_1";
    $rs5 = 'https://es.aptoide.com/search?query='.urlencode($match[2])."&type=apps";
    $rs6 = 'http://html5.oms.apps.opera.com/en_in/catalog.php?search='.urlencode($match[2]);
    $rs7 = 'https://www.androiddrawer.com/search-results/?q='.urlencode($match[2]);
        bot('sendChatAction', [
    'chat_id'=>$chat_id,
        'action'=>'typing',
         ]);
             sleep(1);
   bot('sendMessage', [
    'chat_id'=>$chat_id,
    'parse_mode'=>'markdown',
    'text'=>"*Sir Done Search,*\n\n[Googli Play Market]($rs)\n\n[Mobogenie Market]($rs1)\n\n[Mobo Market]($rs2)\n\n[Apkmirror Market]($rs3)\n\n[Appsodo Market]($rs4)\n\n[Appoide Market]($rs5)\n\n[Opera Market]($rs5)\n\n[Androide Dwar Market]($rs7)\n",
    ]);
       bot('sendChatAction', [
    'chat_id'=>$chat_id,
        'action'=>'typing',
         ]);
             sleep(5);
              bot('sendMessage', [
    'chat_id'=>$chat_id,
    'parse_mode'=>'markdown',
    'text'=>"_Thank you for using the bot_\n\n[Creator Bot](t.me/drcypher)",
       'reply_markup'=>json_encode([
  'inline_keyboard'=>[
  [
  ['text'=>"Channel Bot","url"=>"https://telegram.me/ikuto_Api"]
  ]
  ]
  ])
  ]);
  }