<?php
if(preg_match('/^\/(red) (.*)/s',$text)){
    $text = str_replace('/red ','',$text);
    	$text = str_replace('/red ','',$text);
	$photo = file_get_contents("http://www.flamingtext.com/net-fu/proxy_form.cgi?imageoutput=true&script=amped-logo&text=".urlencode($text)."&doScale=true&scaleWidth=240&scaleHeight=120");
	file_put_contents('Admin/red.png',$photo);
	bot('sendPhoto',[
'chat_id'=>$chat_id,
'photo'=> new CURLFile('Admin/red.png'),
  ]);
  }

    if(preg_match('/^\/(white) (.*)/s',$text)){
    $text = str_replace('/white ','',$text);
    	$text = str_replace('/white ','',$text);
	$photo = file_get_contents("http://www.flamingtext.com/net-fu/proxy_form.cgi?imageoutput=true&script=brushed-metal-logo&text=".urlencode($text)."&doScale=true&scaleWidth=240&scaleHeight=120");
	file_put_contents('Admin/white.png',$photo);
	bot('sendPhoto',[
'chat_id'=>$chat_id,
'photo'=> new CURLFile('Admin/white.png'),
  ]);
  }
  if(preg_match('/^\/(fxwhite) (.*)/s',$text)){
    $text = str_replace('/fxwhite ','',$text);
    	$text = str_replace('/fxwhite ','',$text);
	$photo = file_get_contents("http://www.flamingtext.com/net-fu/proxy_form.cgi?imageoutput=true&script=warrior-logo&text=".urlencode($text)."&doScale=true&scaleWidth=240&scaleHeight=120");
	file_put_contents('Admin/fxwhite.png',$photo);
	bot('sendPhoto',[
'chat_id'=>$chat_id,
'photo'=> new CURLFile('Admin/fxwhite.png'),
  ]);
  }
  
   if(preg_match('/^\/(red2) (.*)/s',$text)){
    $text = str_replace('/red2 ','',$text);
    	$text = str_replace('/red2 ','',$text);
	$photo = file_get_contents("http://www.flamingtext.com/net-fu/proxy_form.cgi?imageoutput=true&script=comics-logo&text=".urlencode($text)."&doScale=true&scaleWidth=240&scaleHeight=120");
	file_put_contents('Admin/red2.png',$photo);
	bot('sendphoto',[
'chat_id'=>$chat_id,
'photo'=> new CURLFile('Admin/red2.png'),
  ]);
  }
   if(preg_match('/^\/(storm) (.*)/s',$text)){
    $text = str_replace('/storm ','',$text);
    	$text = str_replace('/storm ','',$text);
	$photo = file_get_contents("http://www.flamingtext.com/net-fu/proxy_form.cgi?imageoutput=true&script=electric&text=".urlencode($text)."&doScale=true&scaleWidth=240&scaleHeight=120");
	file_put_contents('Admin/storm.png',$photo);
	bot('sendphoto',[
'chat_id'=>$chat_id,
'photo'=> new CURLFile('Admin/storm.png'),
  ]);
  }
    if(preg_match('/^\/(blue) (.*)/s',$text)){
    $text = str_replace('/blue ','',$text);
    	$text = str_replace('/blue ','',$text);
	$photo = file_get_contents("http://www.flamingtext.com/net-fu/proxy_form.cgi?imageoutput=true&script=birdy-logo&text=".urlencode($text)."&doScale=true&scaleWidth=240&scaleHeight=120");
	file_put_contents('Admin/blue.png',$photo);
	bot('sendphoto',[
'chat_id'=>$chat_id,
'photo'=> new CURLFile('Admin/blue.png'),
  ]);
  }
 if(preg_match('/^\/(matrx) (.*)/s',$text)){
    $text = str_replace('/matrx ','',$text);
    	$text = str_replace('/matrx ','',$text);
	$photo = file_get_contents("http://www.flamingtext.com/net-fu/proxy_form.cgi?imageoutput=true&script=matrix-logo&text=".urlencode($text)."&doScale=true&scaleWidth=240&scaleHeight=120");
	file_put_contents('Admin/matrx.png',$photo);
	bot('sendphoto',[
'chat_id'=>$chat_id,
'photo'=> new CURLFile('Admin/matrx.png'),
  ]);
  }
   if(preg_match('/^\/(wave) (.*)/s',$text)){
    $text = str_replace('/wave ','',$text);
    	$text = str_replace('/wave ','',$text);
	$photo = file_get_contents("http://www.flamingtext.com/net-fu/proxy_form.cgi?imageoutput=true&script=flame-logo&text=".urlencode($text)."&doScale=true&scaleWidth=240&scaleHeight=120");
	file_put_contents('Admin/wave.png',$photo);
	bot('sendphoto',[
'chat_id'=>$chat_id,
'photo'=> new CURLFile('Admin/wave.png'),
  ]);
  }