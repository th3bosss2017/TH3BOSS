<?php
########## تحويل الرسائل الى  المطور ##########
$username = $message->from->username;
if($text and $msg_type == 'private'){
bot('sendmessage',[
'chat_id'=>$sudo_id,
'text'=>"رساله مرسله من @$username اليك \n$text",
]);
}

if($text == "/leave" && $id_me == $sudo_id){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"*Bye*",
'parse_mode'=>"MarkDown",
]);
bot('leaveChat',[
'chat_id'=>$chat_id,
]);
}
