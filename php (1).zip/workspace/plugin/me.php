<?php
$rand1 = array("http://store4.up-00.com/2017-07/150030145074041.png");
$ra = array_rand($rand1, 1);
if($text == '/me'and $id_me == $sudo_id ){
  bot('sendphoto',[
    'chat_id'=>$chat_id,
    'photo' => $rand1[$ra],
    'reply_to_message_id'=>$message_id
  ]);
  }
$rand1 = array("http://store6.up-00.com/2017-07/150031268860831.png");
$ra = array_rand($rand1, 1);
if($text == 'موقعي' and strpos($proadmin , '"status":"member"') == false ){
  bot('sendphoto',[
    'chat_id'=>$chat_id,
    'photo' => $rand1[$ra],
    'reply_to_message_id'=>$message_id
  ]);
  }
  $rand1 = array("http://store6.up-00.com/2017-07/15003130581651.png");
$ra = array_rand($rand1, 1);
if($text == 'موقعي' and strpos($proadmin , '"status":"member"') !== false ){
  bot('sendphoto',[
    'chat_id'=>$chat_id,
    'photo' => $rand1[$ra],
    'reply_to_message_id'=>$message_id
  ]);
  }