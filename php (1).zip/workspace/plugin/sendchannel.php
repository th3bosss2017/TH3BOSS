<?php
$photo = $message->photo;
$idph = $update->message->photo[0]->file_id;
$exx = explode("/send", $text);
if($exx){
bot('sendmessage',[
'chat_id'=>-1001120117246,
'text'=>$exx[1],
       'reply_markup'=>json_encode([
  'inline_keyboard'=>[
  [
  ['text'=>"1","url"=>"https://telegram.me/ikuto_Api"], ['text'=>"2","url"=>"https://telegram.me/ikuto_Api"]
  ]
  ]
  ])
  ]);
}

