<?php

$rep = $message->reply_to_message; 
$rep_msg = $rep->message_id; 
############# حذف الرساله بلرد #########
if($rep && $text == 'مسح'){
bot('deleteMessage',[
'chat_id'=>$chat_id,
'message_id'=>$rep_msg
]);
if(stristr($text ,مسح)){
  bot('deleteMessage', [
  'chat_id'=>$chat_id,
  'message_id'=>$message_id
  ]);
}
} 
   
  ################حذف الرسال بلعدد ####################
$delete = explode(' ', $text);
$mid = $message->message_id;
if($delete[0] == 'تنظيف' and isset($delete[1]) and $delete[1] < 90){

for($i = $mid - $delete[1]; $i < $mid; $i++){

bot('deleteMessage',[
'chat_id'=>$chat_id,
'message_id'=>$i
]); 

}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'🌟| مرحبا عزيزي ' . $delete[1] . '🌟| تم تنظيف من المجموعه'

]);

}


if($delete[0] == 'تنظيف' and isset($delete[1]) and $delete[1] > 90){
 
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'dont delete <100',
'reply_to_message_id'=>$message->message_id
]);

}
################## طرد  عضو  وحضر العضو #############
$replay_user = $message->reply_to_message->from->username;
if($text == 'طرد' and $rep){
  bot('kickChatMember',[
    'chat_id'=>$chat_id,
    'user_id'=>$message->reply_to_message->from->id,
  ]);

  bot('sendmessage',[
  'chat_id'=>$chat_id,
  'text'=>"🌟| مرحبا عزيزي تم طرد العضو @$replay_user",
  'reply_to_message_id'=>$message_id
]);
}
##فرعون
if($text == 'حظر' and $rep){
  bot('kickChatMember',[
    'chat_id'=>$chat_id,
    'user_id'=>$message->reply_to_message->from->id,
  ]);

  bot('sendmessage',[
  'chat_id'=>$chat_id,
  'text'=>"🌟| مرحبا عزيزي تم حظر العضو @$replay_user",
  'reply_to_message_id'=>$message_id
]);
}
##الغاء الحضر 
if($text == 'الغاء الحظر' and $rep){
  bot('unbanChatMember',[
    'chat_id'=>$chat_id,
    'user_id'=>$message->reply_to_message->from->id,
  ]);
  bot('sendmessage',[
  'chat_id'=>$chat_id,
  'text'=>"🌟| مرحبا عزيزي تم الغاء حظر العضو @$replay_user",
  'reply_to_message_id'=>$message_id
]);
}
############ ضع اسم للمجموعه ############
$title = str_replace("/set name ","$title",$text);
if($text=="ضع اسم $title"){
bot('setChatTitle',[
'chat_id'=>$chat_id,
'title'=>"$title"
]);
}

################# تثبيت الرسائل والاء تثبيت ############
if($rep && $text=="تثبيت"){
bot('pinChatMessage',[
'chat_id'=>$chat_id,
'message_id'=>$rep_msg
]);
}
if($text=="الغاء تثبيت"){
bot('unpinChatMessage',[
'chat_id'=>$chat_id,
]);
}
######################## حاسبه ####################
if(preg_match('/^\/([Cc]alc) (.*)/s',$text)){
    preg_match('/^\/([Cc]alc) (.*)/s',$text,$match);
    $rs = file_get_contents('http://api.mathjs.org/v1/?expr='.urlencode($match[2]));
   bot('sendMessage', [
    'chat_id'=>$chat_id,
    'text'=>$rs,
    ]);
}
######################## اختصار الروابط####################
if(preg_match('/^\/([Ss]hort) (.*)/s',$text)){
	preg_match('/^\/([Ss]hort) (.*)/s',$text,$match);
	$short = file_get_contents("https://api-ssl.bitly.com/v3/shorten?access_token=f2d0b4eabb524aaaf22fbc51ca620ae0fa16753d&longUrl=".$match[2]);
	$po = json_decode($short);
		bot('sendMessage',[
	'chat_id'=>$chat_id,
	'text'=>$po->data->url,
	]);
	}

?>