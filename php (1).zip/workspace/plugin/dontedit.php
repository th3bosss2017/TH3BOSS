<?php
$edit_bot = $update->edited_message;
$file_o = __DIR__.'/users/'.$message_id.'.json';
file_put_contents($file_o,json_encode($update->message->text));
chmod($file_o,0777);
if (isset($update->edited_message)){
  $edit_id = $edit_bot->message_id;
  $first1 = $edit_bot->from->first_name;
  $klma= json_decode(file_get_contents(__DIR__.'/users/'.$edit_id.'.json'));
  $text = "I have seen your \nedit to the message *$first1*".$klma;
  $id = $update->edited_message->chat->id;
  bot('sendmessage',[
    'chat_id'=>$id,
    'reply_to_message_id'=>$edit_id,
    'text'=>$text,
    'parse_mode'=>'markdown'
  ]);
}



?>
